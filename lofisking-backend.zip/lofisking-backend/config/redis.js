const { createClient } = require('redis');
let client;

const getClient = async () => {
  if (client && client.isReady) return client;
  client = createClient({ url: process.env.REDIS_URL || 'redis://localhost:6379' });
  client.on('error', (err) => console.error('Redis:', err));
  await client.connect();
  return client;
};

module.exports = {
  getClient,
  async set(key, val, ex = 3600) { const r = await getClient(); await r.setEx(key, ex, JSON.stringify(val)); },
  async get(key) { const r = await getClient(); const v = await r.get(key); return v ? JSON.parse(v) : null; },
  async del(key) { const r = await getClient(); await r.del(key); },
  async setOTP(id, otp) { const r = await getClient(); await r.setEx('otp:'+id, 600, otp); },
  async getOTP(id)       { const r = await getClient(); return r.get('otp:'+id); },
  async delOTP(id)       { const r = await getClient(); await r.del('otp:'+id); },
};

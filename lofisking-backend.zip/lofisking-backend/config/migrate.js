require('dotenv').config();
const { query } = require('./db');

const SQL = `
-- USERS
CREATE TABLE IF NOT EXISTS users (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name         VARCHAR(120),
  email        VARCHAR(255) UNIQUE,
  phone        VARCHAR(30)  UNIQUE,
  password_hash TEXT NOT NULL,
  ig_handle    VARCHAR(60),
  ig_token     TEXT,
  ig_token_enc TEXT,
  niche        VARCHAR(60) DEFAULT 'creator',
  plan         VARCHAR(20) DEFAULT 'free',
  created_at   TIMESTAMPTZ DEFAULT NOW(),
  updated_at   TIMESTAMPTZ DEFAULT NOW()
);

-- REELS
CREATE TABLE IF NOT EXISTS reels (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id      UUID REFERENCES users(id) ON DELETE CASCADE,
  title        VARCHAR(255),
  video_url    TEXT,
  thumbnail_url TEXT,
  caption      TEXT,
  hashtags     TEXT[],
  status       VARCHAR(20) DEFAULT 'draft',
  ig_media_id  VARCHAR(60),
  posted_at    TIMESTAMPTZ,
  created_at   TIMESTAMPTZ DEFAULT NOW()
);

-- ANALYTICS
CREATE TABLE IF NOT EXISTS analytics (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  reel_id      UUID REFERENCES reels(id) ON DELETE CASCADE,
  user_id      UUID REFERENCES users(id) ON DELETE CASCADE,
  views        INTEGER DEFAULT 0,
  likes        INTEGER DEFAULT 0,
  comments     INTEGER DEFAULT 0,
  shares       INTEGER DEFAULT 0,
  saves        INTEGER DEFAULT 0,
  reach        INTEGER DEFAULT 0,
  retention    DECIMAL(5,2) DEFAULT 0,
  recorded_at  TIMESTAMPTZ DEFAULT NOW()
);

-- SCHEDULES
CREATE TABLE IF NOT EXISTS schedules (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id      UUID REFERENCES users(id) ON DELETE CASCADE,
  reel_id      UUID REFERENCES reels(id) ON DELETE CASCADE,
  post_time    TIMESTAMPTZ NOT NULL,
  status       VARCHAR(20) DEFAULT 'scheduled',
  job_id       VARCHAR(120),
  error_msg    TEXT,
  created_at   TIMESTAMPTZ DEFAULT NOW()
);

-- SESSIONS (refresh tokens)
CREATE TABLE IF NOT EXISTS sessions (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id      UUID REFERENCES users(id) ON DELETE CASCADE,
  refresh_token TEXT NOT NULL,
  expires_at   TIMESTAMPTZ NOT NULL,
  created_at   TIMESTAMPTZ DEFAULT NOW()
);

-- INDEXES
CREATE INDEX IF NOT EXISTS idx_reels_user    ON reels(user_id);
CREATE INDEX IF NOT EXISTS idx_analytics_reel ON analytics(reel_id);
CREATE INDEX IF NOT EXISTS idx_schedules_time ON schedules(post_time, status);
CREATE INDEX IF NOT EXISTS idx_sessions_user  ON sessions(user_id);

SELECT 'Migration complete' as result;
`;

(async () => {
  try {
    const res = await query(SQL);
    console.log('✅', res.rows[res.rows.length-1]?.result);
    process.exit(0);
  } catch (err) {
    console.error('❌ Migration failed:', err.message);
    process.exit(1);
  }
})();

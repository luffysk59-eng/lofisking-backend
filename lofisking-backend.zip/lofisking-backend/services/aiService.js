const axios = require('axios');

const ANTHROPIC_API = 'https://api.anthropic.com/v1/messages';

const callClaude = async (prompt, maxTokens = 1000) => {
  const response = await axios.post(
    ANTHROPIC_API,
    { model: 'claude-sonnet-4-20250514', max_tokens: maxTokens, messages: [{ role: 'user', content: prompt }] },
    { headers: { 'Content-Type': 'application/json', 'x-api-key': process.env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01' } }
  );
  return response.data.content[0].text;
};

const generateCaption = async (niche, keywords = '') => {
  const prompt = `Generate 3 viral Instagram Reels captions for the ${niche} niche. Keywords: ${keywords}. Return JSON array: [{"caption":"text","style":"emotional|viral|educational|cta"}]`;
  const text = await callClaude(prompt, 600);
  const match = text.match(/\[[\s\S]*\]/);
  return match ? JSON.parse(match[0]) : [];
};

const generateHashtags = async (niche, caption = '') => {
  const prompt = `Generate 30 trending Instagram hashtags for ${niche} niche. Caption context: "${caption}". Return JSON: {"viral":["#tag",...8],"niche":["#tag",...8],"growing":["#tag",...6],"micro":["#tag",...5],"daily":["#tag",...3]}`;
  const text = await callClaude(prompt, 500);
  const match = text.match(/\{[\s\S]*\}/);
  return match ? JSON.parse(match[0]) : {};
};

const generateHook = async (niche, format = 'tutorial') => {
  const prompt = `Generate 3 viral hook lines for a ${format} style Instagram Reel in the ${niche} niche. First 3 seconds only. Return JSON array: [{"hook":"text","type":"curiosity|challenge|result|controversy"}]`;
  const text = await callClaude(prompt, 400);
  const match = text.match(/\[[\s\S]*\]/);
  return match ? JSON.parse(match[0]) : [];
};

const analyzeReel = async (caption, hashtags, niche) => {
  const prompt = `Analyze this Instagram Reel for performance. Caption: "${caption}". Hashtags: ${hashtags}. Niche: ${niche}. Return JSON: {"viralScore":0-100,"retentionRate":"XX%","estimatedReach":"XXK","hookStrength":"Poor|Good|Strong|Excellent","hookScore":0-100,"engagementPrediction":"XX%","feedback":"2-3 sentences","improvements":["tip1","tip2","tip3"]}`;
  const text = await callClaude(prompt, 500);
  const match = text.match(/\{[\s\S]*\}/);
  return match ? JSON.parse(match[0]) : null;
};

const getGrowthInsights = async (stats) => {
  const prompt = `Instagram analytics AI advisor. Stats: ${JSON.stringify(stats)}. Give 3 specific growth insights. Return JSON: [{"insight":"text","action":"specific step","impact":"High|Medium|Low"}]`;
  const text = await callClaude(prompt, 500);
  const match = text.match(/\[[\s\S]*\]/);
  return match ? JSON.parse(match[0]) : [];
};

module.exports = { callClaude, generateCaption, generateHashtags, generateHook, analyzeReel, getGrowthInsights };

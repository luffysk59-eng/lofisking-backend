const AWS = require('aws-sdk');
const { v4: uuidv4 } = require('uuid');
const path = require('path');

const s3 = new AWS.S3({
  accessKeyId:     process.env.AWS_ACCESS_KEY_ID,
  secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  region:          process.env.AWS_REGION || 'us-east-1',
});

const BUCKET = process.env.AWS_S3_BUCKET || 'lofisking-videos';

const uploadVideo = async (file) => {
  const ext  = path.extname(file.originalname) || '.mp4';
  const key  = `videos/${uuidv4()}${ext}`;
  const params = {
    Bucket: BUCKET,
    Key:    key,
    Body:   file.buffer,
    ContentType: file.mimetype || 'video/mp4',
    ACL: 'private',
  };
  const result = await s3.upload(params).promise();
  return { url: result.Location, key };
};

const getSignedUrl = (key, expires = 3600) => {
  return s3.getSignedUrlPromise('getObject', { Bucket: BUCKET, Key: key, Expires: expires });
};

const deleteVideo = async (key) => {
  await s3.deleteObject({ Bucket: BUCKET, Key: key }).promise();
};

const getPresignedUploadUrl = async (filename, contentType) => {
  const ext = path.extname(filename) || '.mp4';
  const key = `videos/${uuidv4()}${ext}`;
  const url = await s3.getSignedUrlPromise('putObject', {
    Bucket: BUCKET, Key: key, ContentType: contentType, Expires: 300
  });
  return { uploadUrl: url, key, videoUrl: `https://${BUCKET}.s3.amazonaws.com/${key}` };
};

module.exports = { uploadVideo, getSignedUrl, deleteVideo, getPresignedUploadUrl };

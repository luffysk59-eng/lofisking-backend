const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST || 'smtp.gmail.com',
  port: parseInt(process.env.SMTP_PORT || '587'),
  secure: false,
  auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS },
});

const sendOTP = async (email, otp) => {
  await transporter.sendMail({
    from: process.env.EMAIL_FROM || 'LOFISKING <noreply@lofisking.com>',
    to: email,
    subject: `${otp} — Your LOFISKING verification code`,
    html: `
      <div style="font-family:Arial,sans-serif;max-width:480px;margin:0 auto;background:#0B0B0F;color:#F0F0FA;border-radius:16px;padding:36px;">
        <div style="text-align:center;margin-bottom:28px;">
          <div style="display:inline-block;background:linear-gradient(135deg,#FF007F,#00E5FF);border-radius:12px;padding:10px 20px;">
            <span style="font-size:20px;font-weight:900;color:#000;letter-spacing:2px;">LOFISKING</span>
          </div>
        </div>
        <h2 style="text-align:center;color:#F0F0FA;margin-bottom:8px;">Verification Code</h2>
        <p style="text-align:center;color:rgba(240,240,250,.5);margin-bottom:28px;">Enter this code to verify your account</p>
        <div style="text-align:center;background:rgba(255,0,127,.08);border:1px solid rgba(255,0,127,.25);border-radius:14px;padding:28px;">
          <div style="font-size:42px;font-weight:900;letter-spacing:12px;color:#FF007F;">${otp}</div>
        </div>
        <p style="text-align:center;color:rgba(240,240,250,.4);margin-top:20px;font-size:12px;">
          This code expires in 10 minutes.<br/>If you didn't request this, ignore this email.
        </p>
      </div>
    `,
  });
};

const sendWelcome = async (email, name) => {
  await transporter.sendMail({
    from: process.env.EMAIL_FROM,
    to: email,
    subject: 'Welcome to LOFISKING 👑',
    html: `<p>Hey ${name}, welcome to LOFISKING AI Creator OS!</p>`,
  });
};

module.exports = { sendOTP, sendWelcome };

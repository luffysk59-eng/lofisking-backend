const { query } = require('../config/db');
const { uploadVideo, getPresignedUploadUrl, deleteVideo } = require('../services/s3Service');
const { analyzeReel } = require('../services/aiService');
const { v4: uuidv4 } = require('uuid');

// GET /api/reels
exports.getReels = async (req, res) => {
  try {
    const { page = 1, limit = 20, status } = req.query;
    const offset = (page - 1) * limit;
    let sql = 'SELECT r.*, COALESCE(json_agg(a.*) FILTER (WHERE a.id IS NOT NULL), \'[]\') as analytics FROM reels r LEFT JOIN analytics a ON a.reel_id = r.id WHERE r.user_id=$1';
    const params = [req.user.id];
    if (status) { sql += ` AND r.status=$${params.length+1}`; params.push(status); }
    sql += ` GROUP BY r.id ORDER BY r.created_at DESC LIMIT $${params.length+1} OFFSET $${params.length+2}`;
    params.push(limit, offset);
    const result = await query(sql, params);
    const count  = await query('SELECT COUNT(*) FROM reels WHERE user_id=$1', [req.user.id]);
    res.json({ reels: result.rows, total: parseInt(count.rows[0].count), page: parseInt(page), limit: parseInt(limit) });
  } catch (err) {
    console.error('getReels:', err);
    res.status(500).json({ error: 'Failed to fetch reels' });
  }
};

// POST /api/reels/presign — get S3 upload URL
exports.presignUpload = async (req, res) => {
  try {
    const { filename, contentType } = req.body;
    if (!filename) return res.status(400).json({ error: 'filename required' });
    const data = await getPresignedUploadUrl(filename, contentType || 'video/mp4');
    res.json(data);
  } catch (err) {
    console.error('presign:', err);
    res.status(500).json({ error: 'Failed to generate upload URL' });
  }
};

// POST /api/reels — create reel record after S3 upload
exports.createReel = async (req, res) => {
  try {
    const { title, videoUrl, videoKey, caption, hashtags, thumbnailUrl } = req.body;
    if (!videoUrl) return res.status(400).json({ error: 'videoUrl required' });

    const result = await query(
      'INSERT INTO reels (user_id, title, video_url, thumbnail_url, caption, hashtags, status) VALUES ($1,$2,$3,$4,$5,$6,\'draft\') RETURNING *',
      [req.user.id, title||'Untitled Reel', videoUrl, thumbnailUrl||null, caption||'', hashtags||[]]
    );
    res.status(201).json({ reel: result.rows[0] });
  } catch (err) {
    console.error('createReel:', err);
    res.status(500).json({ error: 'Failed to create reel' });
  }
};

// PUT /api/reels/:id — update reel
exports.updateReel = async (req, res) => {
  try {
    const { title, caption, hashtags, status } = req.body;
    const result = await query(
      'UPDATE reels SET title=COALESCE($1,title), caption=COALESCE($2,caption), hashtags=COALESCE($3,hashtags), status=COALESCE($4,status) WHERE id=$5 AND user_id=$6 RETURNING *',
      [title, caption, hashtags, status, req.params.id, req.user.id]
    );
    if (!result.rows.length) return res.status(404).json({ error: 'Reel not found' });
    res.json({ reel: result.rows[0] });
  } catch (err) {
    res.status(500).json({ error: 'Failed to update reel' });
  }
};

// DELETE /api/reels/:id
exports.deleteReel = async (req, res) => {
  try {
    const result = await query('DELETE FROM reels WHERE id=$1 AND user_id=$2 RETURNING video_url', [req.params.id, req.user.id]);
    if (!result.rows.length) return res.status(404).json({ error: 'Reel not found' });
    res.json({ message: 'Reel deleted' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to delete reel' });
  }
};

// POST /api/reels/:id/analyze
exports.analyzeReelHandler = async (req, res) => {
  try {
    const reel = await query('SELECT * FROM reels WHERE id=$1 AND user_id=$2', [req.params.id, req.user.id]);
    if (!reel.rows.length) return res.status(404).json({ error: 'Reel not found' });
    const r = reel.rows[0];
    const analysis = await analyzeReel(r.caption, (r.hashtags||[]).join(' '), req.user.niche || 'creator');
    res.json({ analysis });
  } catch (err) {
    console.error('analyzeReel:', err);
    res.status(500).json({ error: 'Analysis failed' });
  }
};

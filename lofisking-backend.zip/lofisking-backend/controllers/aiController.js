const { generateCaption, generateHashtags, generateHook, callClaude } = require('../services/aiService');

// POST /api/ai/caption
exports.caption = async (req, res) => {
  try {
    const { niche, keywords } = req.body;
    const captions = await generateCaption(niche || req.user.niche || 'creator', keywords);
    res.json({ captions });
  } catch (err) {
    res.status(500).json({ error: 'Caption generation failed' });
  }
};

// POST /api/ai/hashtags
exports.hashtags = async (req, res) => {
  try {
    const { niche, caption } = req.body;
    const tags = await generateHashtags(niche || req.user.niche, caption);
    res.json({ hashtags: tags });
  } catch (err) {
    res.status(500).json({ error: 'Hashtag generation failed' });
  }
};

// POST /api/ai/hook
exports.hook = async (req, res) => {
  try {
    const { niche, format } = req.body;
    const hooks = await generateHook(niche || req.user.niche, format);
    res.json({ hooks });
  } catch (err) {
    res.status(500).json({ error: 'Hook generation failed' });
  }
};

// POST /api/ai/chat
exports.chat = async (req, res) => {
  try {
    const { message, history = [] } = req.body;
    if (!message) return res.status(400).json({ error: 'message required' });
    const systemCtx = `You are the LOFISKING AI Assistant — expert in Instagram Reels, viral content, captions, hashtags, growth strategy. User niche: ${req.user.niche || 'creator'}.`;
    const prompt = systemCtx + '\n\nConversation:\n' + history.map(m => `${m.role}: ${m.content}`).join('\n') + `\nuser: ${message}\nassistant:`;
    const reply = await callClaude(prompt, 800);
    res.json({ reply });
  } catch (err) {
    res.status(500).json({ error: 'AI chat failed' });
  }
};

// POST /api/ai/intelligence  
exports.intelligence = async (req, res) => {
  try {
    const { query: q, type = 'all' } = req.body;
    if (!q) return res.status(400).json({ error: 'query required' });
    const prompt = `You are LOFISKING AI trained on Instagram data 24/7. Search for: "${q}" (type: ${type}). Return ONLY JSON: {"niche":"detected","hashtags":{"viral":[],"niche":[],"growing":[],"micro":[],"daily":[]},"reelsStrategy":{"hook":"","format":"","duration":"","tips":[]},"viralSongs":[{"title":"","artist":"","uses":"","vibe":"","trending":true}],"captions":[{"type":"","text":"","style":""}],"growthInsights":{"quickWin":"","peakDays":[],"avoid":""}}`;
    const text = await callClaude(prompt, 2000);
    const match = text.match(/\{[\s\S]*\}/);
    const data = match ? JSON.parse(match[0]) : null;
    if (!data) return res.status(500).json({ error: 'AI response parse error' });
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: 'Intelligence search failed' });
  }
};

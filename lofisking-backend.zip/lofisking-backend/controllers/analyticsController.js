const { query } = require('../config/db');
const { getGrowthInsights } = require('../services/aiService');
const { getCache, setCache } = require('../config/redis');

// GET /api/analytics — dashboard overview
exports.getOverview = async (req, res) => {
  try {
    const cacheKey = `analytics:${req.user.id}:overview`;
    const cached = await getCache(cacheKey);
    if (cached) return res.json(cached);

    const [totalViews, topReels, daily] = await Promise.all([
      query('SELECT COALESCE(SUM(views),0) as views, COALESCE(SUM(likes),0) as likes, COALESCE(SUM(comments),0) as comments, COALESCE(SUM(shares),0) as shares, COALESCE(AVG(retention),0) as retention FROM analytics WHERE user_id=$1', [req.user.id]),
      query('SELECT r.title, r.id, SUM(a.views) as views, SUM(a.likes) as likes FROM reels r JOIN analytics a ON a.reel_id=r.id WHERE r.user_id=$1 GROUP BY r.id ORDER BY views DESC LIMIT 5', [req.user.id]),
      query('SELECT DATE(recorded_at) as date, SUM(views) as views, SUM(likes) as likes FROM analytics WHERE user_id=$1 AND recorded_at > NOW()-INTERVAL \'30 days\' GROUP BY DATE(recorded_at) ORDER BY date', [req.user.id]),
    ]);

    const data = { summary: totalViews.rows[0], topReels: topReels.rows, dailyStats: daily.rows };
    await setCache(cacheKey, data, 300);
    res.json(data);
  } catch (err) {
    console.error('getOverview:', err);
    res.status(500).json({ error: 'Failed to fetch analytics' });
  }
};

// GET /api/analytics/:reelId — single reel analytics
exports.getReelAnalytics = async (req, res) => {
  try {
    const result = await query(
      'SELECT a.* FROM analytics a JOIN reels r ON a.reel_id=r.id WHERE a.reel_id=$1 AND r.user_id=$2 ORDER BY a.recorded_at DESC',
      [req.params.reelId, req.user.id]
    );
    res.json({ analytics: result.rows });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch reel analytics' });
  }
};

// POST /api/analytics/:reelId — record analytics data
exports.recordAnalytics = async (req, res) => {
  try {
    const { views, likes, comments, shares, saves, reach, retention } = req.body;
    const result = await query(
      'INSERT INTO analytics (reel_id, user_id, views, likes, comments, shares, saves, reach, retention) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *',
      [req.params.reelId, req.user.id, views||0, likes||0, comments||0, shares||0, saves||0, reach||0, retention||0]
    );
    res.status(201).json({ record: result.rows[0] });
  } catch (err) {
    res.status(500).json({ error: 'Failed to record analytics' });
  }
};

// GET /api/analytics/insights — AI-powered insights
exports.getInsights = async (req, res) => {
  try {
    const stats = await query(
      'SELECT COALESCE(SUM(views),0) as total_views, COALESCE(AVG(retention),0) as avg_retention, COALESCE(SUM(likes),0) as total_likes, COUNT(DISTINCT reel_id) as total_reels FROM analytics WHERE user_id=$1',
      [req.user.id]
    );
    const insights = await getGrowthInsights(stats.rows[0]);
    res.json({ insights });
  } catch (err) {
    res.status(500).json({ error: 'Failed to get insights' });
  }
};

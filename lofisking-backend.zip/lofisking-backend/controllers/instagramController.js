const axios = require('axios');
const { query } = require('../config/db');

const IG_BASE = 'https://graph.instagram.com';
const FB_BASE = 'https://www.facebook.com/dialog/oauth';

// GET /api/instagram/auth-url
exports.getAuthUrl = (req, res) => {
  const params = new URLSearchParams({
    client_id:     process.env.INSTAGRAM_APP_ID,
    redirect_uri:  process.env.INSTAGRAM_REDIRECT_URI,
    scope:         'user_profile,user_media,instagram_basic,instagram_manage_insights,instagram_content_publish',
    response_type: 'code',
    state:         req.user.id,
  });
  res.json({ authUrl: `${FB_BASE}?${params}` });
};

// GET /api/instagram/callback
exports.handleCallback = async (req, res) => {
  try {
    const { code, state: userId } = req.query;
    if (!code) return res.status(400).json({ error: 'No code received' });

    // Exchange code for token
    const tokenRes = await axios.post('https://api.instagram.com/oauth/access_token', new URLSearchParams({
      client_id:     process.env.INSTAGRAM_APP_ID,
      client_secret: process.env.INSTAGRAM_APP_SECRET,
      grant_type:    'authorization_code',
      redirect_uri:  process.env.INSTAGRAM_REDIRECT_URI,
      code,
    }));

    const shortToken = tokenRes.data.access_token;

    // Exchange for long-lived token
    const longRes = await axios.get('https://graph.instagram.com/access_token', {
      params: { grant_type: 'ig_exchange_token', client_secret: process.env.INSTAGRAM_APP_SECRET, access_token: shortToken }
    });

    const token = longRes.data.access_token;

    // Store token
    await query('UPDATE users SET ig_token=$1 WHERE id=$2', [token, userId]);

    // Redirect to frontend
    res.redirect(`${process.env.FRONTEND_URL}?ig_connected=true`);
  } catch (err) {
    console.error('IG callback error:', err.response?.data || err.message);
    res.redirect(`${process.env.FRONTEND_URL}?ig_error=true`);
  }
};

// GET /api/instagram/profile
exports.getProfile = async (req, res) => {
  try {
    const user = await query('SELECT ig_token FROM users WHERE id=$1', [req.user.id]);
    const token = user.rows[0]?.ig_token;
    if (!token) return res.status(400).json({ error: 'Instagram not connected' });

    const profile = await axios.get(`${IG_BASE}/me`, {
      params: { fields: 'id,username,account_type,media_count', access_token: token }
    });
    res.json({ profile: profile.data });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch Instagram profile' });
  }
};

// GET /api/instagram/media
exports.getMedia = async (req, res) => {
  try {
    const user = await query('SELECT ig_token FROM users WHERE id=$1', [req.user.id]);
    const token = user.rows[0]?.ig_token;
    if (!token) return res.status(400).json({ error: 'Instagram not connected' });

    const media = await axios.get(`${IG_BASE}/me/media`, {
      params: { fields: 'id,media_type,media_url,thumbnail_url,caption,like_count,comments_count,timestamp', access_token: token, limit: 20 }
    });
    res.json({ media: media.data.data });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch media' });
  }
};

// GET /api/instagram/insights
exports.getInsights = async (req, res) => {
  try {
    const user = await query('SELECT ig_token FROM users WHERE id=$1', [req.user.id]);
    const token = user.rows[0]?.ig_token;
    if (!token) return res.status(400).json({ error: 'Instagram not connected' });

    const insights = await axios.get(`${IG_BASE}/me/insights`, {
      params: { metric: 'impressions,reach,profile_views,follower_count', period: 'day', access_token: token }
    });
    res.json({ insights: insights.data.data });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch insights' });
  }
};

// POST /api/instagram/publish/:reelId
exports.publishReel = async (req, res) => {
  try {
    const user = await query('SELECT ig_token FROM users WHERE id=$1', [req.user.id]);
    const token = user.rows[0]?.ig_token;
    if (!token) return res.status(400).json({ error: 'Instagram not connected' });

    const reel = await query('SELECT * FROM reels WHERE id=$1 AND user_id=$2', [req.params.reelId, req.user.id]);
    if (!reel.rows.length) return res.status(404).json({ error: 'Reel not found' });

    const r = reel.rows[0];

    // Step 1: Create media container
    const container = await axios.post(`${IG_BASE}/me/media`, null, {
      params: { media_type: 'REELS', video_url: r.video_url, caption: r.caption, access_token: token }
    });

    // Step 2: Check status
    let status = 'IN_PROGRESS';
    let attempts = 0;
    while (status === 'IN_PROGRESS' && attempts < 10) {
      await new Promise(r => setTimeout(r, 3000));
      const check = await axios.get(`${IG_BASE}/${container.data.id}`, {
        params: { fields: 'status_code', access_token: token }
      });
      status = check.data.status_code;
      attempts++;
    }

    if (status !== 'FINISHED') return res.status(500).json({ error: 'Video processing failed' });

    // Step 3: Publish
    const publish = await axios.post(`${IG_BASE}/me/media_publish`, null, {
      params: { creation_id: container.data.id, access_token: token }
    });

    await query("UPDATE reels SET status='published', ig_media_id=$1, posted_at=NOW() WHERE id=$2", [publish.data.id, r.id]);

    res.json({ message: 'Published to Instagram!', mediaId: publish.data.id });
  } catch (err) {
    console.error('Publish error:', err.response?.data || err.message);
    res.status(500).json({ error: 'Failed to publish to Instagram' });
  }
};

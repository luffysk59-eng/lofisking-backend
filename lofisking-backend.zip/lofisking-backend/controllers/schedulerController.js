const { query } = require('../config/db');
const Queue = require('bull');

let scheduleQueue;
const getQueue = () => {
  if (!scheduleQueue) {
    scheduleQueue = new Queue('schedule-posts', process.env.REDIS_URL || 'redis://localhost:6379');
  }
  return scheduleQueue;
};

// GET /api/scheduler
exports.getSchedules = async (req, res) => {
  try {
    const result = await query(
      'SELECT s.*, r.title, r.caption, r.thumbnail_url FROM schedules s JOIN reels r ON s.reel_id=r.id WHERE s.user_id=$1 ORDER BY s.post_time ASC',
      [req.user.id]
    );
    res.json({ schedules: result.rows });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch schedules' });
  }
};

// POST /api/scheduler — schedule a reel
exports.createSchedule = async (req, res) => {
  try {
    const { reelId, postTime } = req.body;
    if (!reelId || !postTime) return res.status(400).json({ error: 'reelId and postTime required' });

    const scheduledAt = new Date(postTime);
    if (scheduledAt <= new Date()) return res.status(400).json({ error: 'Post time must be in the future' });

    // Check reel belongs to user
    const reel = await query('SELECT id FROM reels WHERE id=$1 AND user_id=$2', [reelId, req.user.id]);
    if (!reel.rows.length) return res.status(404).json({ error: 'Reel not found' });

    const delay = scheduledAt.getTime() - Date.now();
    const job = await getQueue().add({ reelId, userId: req.user.id }, { delay, attempts: 3, backoff: { type: 'exponential', delay: 5000 } });

    const result = await query(
      'INSERT INTO schedules (user_id, reel_id, post_time, status, job_id) VALUES ($1,$2,$3,\'scheduled\',$4) RETURNING *',
      [req.user.id, reelId, scheduledAt, String(job.id)]
    );
    await query("UPDATE reels SET status='scheduled' WHERE id=$1", [reelId]);

    res.status(201).json({ schedule: result.rows[0] });
  } catch (err) {
    console.error('createSchedule:', err);
    res.status(500).json({ error: 'Failed to schedule post' });
  }
};

// DELETE /api/scheduler/:id — cancel schedule
exports.cancelSchedule = async (req, res) => {
  try {
    const result = await query('SELECT * FROM schedules WHERE id=$1 AND user_id=$2', [req.params.id, req.user.id]);
    if (!result.rows.length) return res.status(404).json({ error: 'Schedule not found' });

    const s = result.rows[0];
    if (s.job_id) {
      try {
        const job = await getQueue().getJob(s.job_id);
        if (job) await job.remove();
      } catch (_) {}
    }
    await query("UPDATE schedules SET status='cancelled' WHERE id=$1", [req.params.id]);
    await query("UPDATE reels SET status='draft' WHERE id=$1", [s.reel_id]);

    res.json({ message: 'Schedule cancelled' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to cancel schedule' });
  }
};

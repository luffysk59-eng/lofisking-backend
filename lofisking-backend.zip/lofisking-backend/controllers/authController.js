const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const { query } = require('../config/db');
const redis = require('../config/redis');
const { sendOTP, sendWelcome } = require('../services/emailService');

// Generate tokens
const signTokens = (userId) => {
  const access  = jwt.sign({ userId }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || '7d' });
  const refresh = jwt.sign({ userId }, process.env.JWT_REFRESH_SECRET, { expiresIn: '30d' });
  return { access, refresh };
};

// POST /api/auth/register
exports.register = async (req, res) => {
  try {
    const { name, email, phone, password, igHandle } = req.body;
    const identifier = email || phone;

    // Check duplicate
    const exists = await query('SELECT id FROM users WHERE email=$1 OR phone=$2', [email||null, phone||null]);
    if (exists.rows.length) return res.status(409).json({ error: 'Account already exists with this email or phone' });

    const hash = await bcrypt.hash(password, 12);
    const result = await query(
      'INSERT INTO users (name, email, phone, password_hash, ig_handle) VALUES ($1,$2,$3,$4,$5) RETURNING id, name, email, phone, niche, plan',
      [name, email||null, phone||null, hash, igHandle||null]
    );
    const user = result.rows[0];

    // Send welcome email
    if (email) sendWelcome(email, name).catch(()=>{});

    const tokens = signTokens(user.id);
    await query('INSERT INTO sessions (user_id, refresh_token, expires_at) VALUES ($1,$2,NOW()+INTERVAL \'30 days\')', [user.id, tokens.refresh]);

    res.status(201).json({ message: 'Account created', user, tokens });
  } catch (err) {
    console.error('Register error:', err);
    res.status(500).json({ error: 'Registration failed' });
  }
};

// POST /api/auth/login
exports.login = async (req, res) => {
  try {
    const { identifier, password } = req.body;
    const isEmail = identifier.includes('@');

    const result = await query(
      isEmail
        ? 'SELECT * FROM users WHERE email=$1'
        : 'SELECT * FROM users WHERE phone=$1',
      [identifier]
    );
    if (!result.rows.length) return res.status(401).json({ error: 'Invalid credentials' });

    const user = result.rows[0];
    const valid = await bcrypt.compare(password, user.password_hash);
    if (!valid) return res.status(401).json({ error: 'Invalid credentials' });

    const tokens = signTokens(user.id);
    await query('INSERT INTO sessions (user_id, refresh_token, expires_at) VALUES ($1,$2,NOW()+INTERVAL \'30 days\')', [user.id, tokens.refresh]);

    const safe = { id: user.id, name: user.name, email: user.email, phone: user.phone, niche: user.niche, plan: user.plan, ig_handle: user.ig_handle };
    res.json({ message: 'Login successful', user: safe, tokens });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ error: 'Login failed' });
  }
};

// POST /api/auth/send-otp
exports.sendOTPHandler = async (req, res) => {
  try {
    const { identifier } = req.body;
    const otp = String(Math.floor(1000 + Math.random() * 9000));
    await redis.setOTP(identifier, otp);

    const isEmail = identifier.includes('@');
    if (isEmail) {
      await sendOTP(identifier, otp);
      res.json({ message: 'OTP sent to email', type: 'email' });
    } else {
      // SMS: integrate Twilio/AWS SNS here
      console.log(`SMS OTP for ${identifier}: ${otp}`);
      res.json({ message: 'OTP sent to phone', type: 'sms', _demo_otp: process.env.NODE_ENV !== 'production' ? otp : undefined });
    }
  } catch (err) {
    console.error('OTP send error:', err);
    res.status(500).json({ error: 'Failed to send OTP' });
  }
};

// POST /api/auth/verify-otp
exports.verifyOTPHandler = async (req, res) => {
  try {
    const { identifier, otp } = req.body;
    const stored = await redis.getOTP(identifier);
    if (!stored) return res.status(400).json({ error: 'OTP expired. Request a new one.' });
    if (stored !== otp) return res.status(400).json({ error: 'Invalid OTP' });

    await redis.delOTP(identifier);

    // Find or create user
    const isEmail = identifier.includes('@');
    let result = await query(
      isEmail ? 'SELECT * FROM users WHERE email=$1' : 'SELECT * FROM users WHERE phone=$1',
      [identifier]
    );

    let user;
    if (!result.rows.length) {
      // Auto-create minimal account
      const tmpHash = await bcrypt.hash(uuidv4(), 10);
      result = await query(
        'INSERT INTO users (email, phone, password_hash, name) VALUES ($1,$2,$3,$4) RETURNING *',
        [isEmail ? identifier : null, isEmail ? null : identifier, tmpHash, 'Creator']
      );
    }
    user = result.rows[0];

    const tokens = signTokens(user.id);
    await query('INSERT INTO sessions (user_id, refresh_token, expires_at) VALUES ($1,$2,NOW()+INTERVAL \'30 days\')', [user.id, tokens.refresh]);

    res.json({ message: 'OTP verified', user: { id: user.id, name: user.name, email: user.email, niche: user.niche }, tokens });
  } catch (err) {
    console.error('Verify OTP error:', err);
    res.status(500).json({ error: 'Verification failed' });
  }
};

// POST /api/auth/refresh
exports.refreshToken = async (req, res) => {
  try {
    const { refreshToken } = req.body;
    if (!refreshToken) return res.status(401).json({ error: 'No refresh token' });

    const decoded = jwt.verify(refreshToken, process.env.JWT_REFRESH_SECRET);
    const session = await query('SELECT * FROM sessions WHERE refresh_token=$1 AND expires_at > NOW()', [refreshToken]);
    if (!session.rows.length) return res.status(401).json({ error: 'Invalid or expired session' });

    const tokens = signTokens(decoded.userId);
    await query('UPDATE sessions SET refresh_token=$1, expires_at=NOW()+INTERVAL \'30 days\' WHERE id=$2', [tokens.refresh, session.rows[0].id]);

    res.json({ tokens });
  } catch (err) {
    res.status(401).json({ error: 'Invalid refresh token' });
  }
};

// POST /api/auth/logout
exports.logout = async (req, res) => {
  try {
    const { refreshToken } = req.body;
    if (refreshToken) await query('DELETE FROM sessions WHERE refresh_token=$1', [refreshToken]);
    res.json({ message: 'Logged out' });
  } catch (err) {
    res.status(500).json({ error: 'Logout failed' });
  }
};

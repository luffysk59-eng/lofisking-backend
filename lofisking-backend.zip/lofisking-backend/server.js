require('dotenv').config();
const express  = require('express');
const cors     = require('cors');
const helmet   = require('helmet');
const morgan   = require('morgan');
const { apiLimiter } = require('./middleware/rateLimit');

const app = express();

// ── SECURITY MIDDLEWARE ──
app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));
app.use(cors({
  origin: process.env.FRONTEND_URL || '*',
  credentials: true,
  methods: ['GET','POST','PUT','DELETE','OPTIONS'],
  allowedHeaders: ['Content-Type','Authorization'],
}));

// ── PARSING ──
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// ── LOGGING ──
app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));

// ── RATE LIMITING ──
app.use('/api/', apiLimiter);

// ── HEALTH CHECK ──
app.get('/health', (req, res) => res.json({
  status: 'ok',
  service: 'LOFISKING API',
  version: '1.0.0',
  timestamp: new Date().toISOString(),
  env: process.env.NODE_ENV
}));

// ── ROUTES ──
app.use('/api/auth',       require('./routes/auth'));
app.use('/api/user',       require('./routes/user'));
app.use('/api/reels',      require('./routes/reels'));
app.use('/api/analytics',  require('./routes/analytics'));
app.use('/api/ai',         require('./routes/ai'));
app.use('/api/scheduler',  require('./routes/scheduler'));
app.use('/api/instagram',  require('./routes/instagram'));

// ── 404 HANDLER ──
app.use((req, res) => res.status(404).json({ error: `Route ${req.method} ${req.path} not found` }));

// ── ERROR HANDLER ──
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err);
  res.status(500).json({
    error: process.env.NODE_ENV === 'production' ? 'Internal server error' : err.message
  });
});

// ── START ──
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`\n🚀 LOFISKING API running on port ${PORT}`);
  console.log(`📡 Health: http://localhost:${PORT}/health`);
  console.log(`🔐 Auth:   http://localhost:${PORT}/api/auth`);
  console.log(`🎥 Reels:  http://localhost:${PORT}/api/reels`);
  console.log(`🤖 AI:     http://localhost:${PORT}/api/ai`);
  console.log(`📊 Stats:  http://localhost:${PORT}/api/analytics`);
  console.log(`📅 Queue:  http://localhost:${PORT}/api/scheduler`);
  console.log(`📸 IG:     http://localhost:${PORT}/api/instagram\n`);
});

module.exports = app;

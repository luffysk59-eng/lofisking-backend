require('dotenv').config();
const Queue  = require('bull');
const { query } = require('../config/db');
const instagramCtrl = require('../controllers/instagramController');

const scheduleQueue = new Queue('schedule-posts', process.env.REDIS_URL || 'redis://localhost:6379');

console.log('🔧 LOFISKING Scheduler Worker started');

scheduleQueue.process(async (job) => {
  const { reelId, userId } = job.data;
  console.log(`📅 Processing job ${job.id} — reel ${reelId}`);

  try {
    // Update status to publishing
    await query("UPDATE schedules SET status='publishing' WHERE job_id=$1", [String(job.id)]);
    await query("UPDATE reels SET status='publishing' WHERE id=$1", [reelId]);

    // Get user token
    const userResult = await query('SELECT ig_token FROM users WHERE id=$1', [userId]);
    const token = userResult.rows[0]?.ig_token;

    if (!token) {
      throw new Error('Instagram not connected');
    }

    // Get reel
    const reelResult = await query('SELECT * FROM reels WHERE id=$1', [reelId]);
    if (!reelResult.rows.length) throw new Error('Reel not found');
    const reel = reelResult.rows[0];

    // Publish to Instagram
    const axios = require('axios');
    const IG_BASE = 'https://graph.instagram.com';

    const container = await axios.post(`${IG_BASE}/me/media`, null, {
      params: { media_type: 'REELS', video_url: reel.video_url, caption: reel.caption, access_token: token }
    });

    let status = 'IN_PROGRESS';
    let attempts = 0;
    while (status === 'IN_PROGRESS' && attempts < 15) {
      await new Promise(r => setTimeout(r, 4000));
      const check = await axios.get(`${IG_BASE}/${container.data.id}`, {
        params: { fields: 'status_code', access_token: token }
      });
      status = check.data.status_code;
      attempts++;
    }
    if (status !== 'FINISHED') throw new Error('Video processing timeout');

    const publish = await axios.post(`${IG_BASE}/me/media_publish`, null, {
      params: { creation_id: container.data.id, access_token: token }
    });

    await query("UPDATE reels SET status='published', ig_media_id=$1, posted_at=NOW() WHERE id=$2", [publish.data.id, reelId]);
    await query("UPDATE schedules SET status='published' WHERE job_id=$1", [String(job.id)]);

    console.log(`✅ Reel ${reelId} published successfully`);
    return { success: true, mediaId: publish.data.id };

  } catch (err) {
    console.error(`❌ Job ${job.id} failed:`, err.message);
    await query("UPDATE schedules SET status='failed', error_msg=$1 WHERE job_id=$2", [err.message, String(job.id)]);
    await query("UPDATE reels SET status='draft' WHERE id=$1", [reelId]);
    throw err;
  }
});

scheduleQueue.on('completed', (job) => console.log(`✅ Job ${job.id} completed`));
scheduleQueue.on('failed',    (job, err) => console.error(`❌ Job ${job.id} failed: ${err.message}`));
scheduleQueue.on('stalled',   (job) => console.warn(`⚠️ Job ${job.id} stalled`));

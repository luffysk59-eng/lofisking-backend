# LOFISKING Backend API

Complete Node.js + Express backend for the LOFISKING AI Creator OS.

## Stack
- **Runtime**: Node.js + Express
- **Database**: PostgreSQL (Supabase / AWS RDS)
- **Cache + Queue**: Redis + Bull.js
- **Storage**: AWS S3
- **AI**: Anthropic Claude API
- **Auth**: JWT (access + refresh tokens) + OTP
- **Instagram**: OAuth 2.0 + Graph API

## Setup

### 1. Install dependencies
```bash
npm install
```

### 2. Configure environment
```bash
cp .env.example .env
# Fill in all values in .env
```

### 3. Run database migrations
```bash
npm run migrate
```

### 4. Start server
```bash
# Development
npm run dev

# Production
npm start

# Background scheduler worker (separate process)
npm run worker
```

## API Endpoints

### Auth — `/api/auth`
| Method | Path | Description |
|--------|------|-------------|
| POST | `/register` | Create account (email or phone) |
| POST | `/login` | Login with identifier + password |
| POST | `/send-otp` | Send 4-digit OTP to email/phone |
| POST | `/verify-otp` | Verify OTP and get tokens |
| POST | `/refresh` | Refresh access token |
| POST | `/logout` | Invalidate session |

### Reels — `/api/reels` 🔐
| Method | Path | Description |
|--------|------|-------------|
| GET | `/` | Get all user reels |
| POST | `/presign` | Get S3 upload URL |
| POST | `/` | Create reel record |
| PUT | `/:id` | Update reel |
| DELETE | `/:id` | Delete reel |
| POST | `/:id/analyze` | AI analyze reel |

### AI Engine — `/api/ai` 🔐
| Method | Path | Description |
|--------|------|-------------|
| POST | `/caption` | Generate viral captions |
| POST | `/hashtags` | Generate hashtag sets |
| POST | `/hook` | Generate hook lines |
| POST | `/chat` | AI assistant chat |
| POST | `/intelligence` | Full AI intelligence search |

### Analytics — `/api/analytics` 🔐
| Method | Path | Description |
|--------|------|-------------|
| GET | `/` | Dashboard overview |
| GET | `/insights` | AI growth insights |
| GET | `/:reelId` | Single reel analytics |
| POST | `/:reelId` | Record analytics data |

### Scheduler — `/api/scheduler` 🔐
| Method | Path | Description |
|--------|------|-------------|
| GET | `/` | Get all scheduled posts |
| POST | `/` | Schedule a reel |
| DELETE | `/:id` | Cancel scheduled post |

### Instagram — `/api/instagram` 🔐
| Method | Path | Description |
|--------|------|-------------|
| GET | `/auth-url` | Get OAuth URL |
| GET | `/callback` | OAuth callback |
| GET | `/profile` | Get IG profile |
| GET | `/media` | Get IG media |
| GET | `/insights` | Get IG insights |
| POST | `/publish/:reelId` | Publish reel to Instagram |

### User — `/api/user` 🔐
| Method | Path | Description |
|--------|------|-------------|
| GET | `/me` | Get current user |
| PUT | `/me` | Update profile |

## Deployment

### Railway (recommended — free tier)
```bash
railway login
railway init
railway add postgresql redis
railway up
```

### Render
1. Connect GitHub repo
2. Add environment variables
3. Deploy

### Environment variables needed
See `.env.example` for all required variables.

## Database Schema
- `users` — accounts, ig_token, niche, plan
- `reels` — videos, captions, hashtags, status
- `analytics` — views, likes, comments, shares, retention
- `schedules` — post queue with job IDs
- `sessions` — refresh tokens

🔐 = requires Authorization: Bearer {token} header

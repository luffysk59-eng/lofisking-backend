const express = require('express');
const router  = express.Router();
const ctrl    = require('../controllers/aiController');
const auth    = require('../middleware/auth');
const rateLimit = require('express-rate-limit');

const aiLimiter = rateLimit({ windowMs: 60000, max: 30, message: { error: 'AI rate limit reached' } });

router.use(auth);
router.post('/caption',       aiLimiter, ctrl.caption);
router.post('/hashtags',      aiLimiter, ctrl.hashtags);
router.post('/hook',          aiLimiter, ctrl.hook);
router.post('/chat',          aiLimiter, ctrl.chat);
router.post('/intelligence',  aiLimiter, ctrl.intelligence);

module.exports = router;

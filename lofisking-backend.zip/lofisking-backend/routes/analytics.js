const express = require('express');
const router  = express.Router();
const ctrl    = require('../controllers/analyticsController');
const auth    = require('../middleware/auth');

router.use(auth);
router.get('/',                    ctrl.getOverview);
router.get('/insights',            ctrl.getInsights);
router.get('/:reelId',             ctrl.getReelAnalytics);
router.post('/:reelId',            ctrl.recordAnalytics);

module.exports = router;

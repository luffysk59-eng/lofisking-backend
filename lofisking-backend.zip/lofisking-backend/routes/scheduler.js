const express = require('express');
const router  = express.Router();
const ctrl    = require('../controllers/schedulerController');
const auth    = require('../middleware/auth');

router.use(auth);
router.get('/',      ctrl.getSchedules);
router.post('/',     ctrl.createSchedule);
router.delete('/:id', ctrl.cancelSchedule);

module.exports = router;

const express = require('express');
const router  = express.Router();
const ctrl    = require('../controllers/reelController');
const auth    = require('../middleware/auth');
const { uploadLimiter } = require('../middleware/rateLimit');

router.use(auth);
router.get('/',                        ctrl.getReels);
router.post('/presign', uploadLimiter, ctrl.presignUpload);
router.post('/',                       ctrl.createReel);
router.put('/:id',                     ctrl.updateReel);
router.delete('/:id',                  ctrl.deleteReel);
router.post('/:id/analyze',            ctrl.analyzeReelHandler);

module.exports = router;

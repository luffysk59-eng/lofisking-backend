const express = require('express');
const router  = express.Router();
const ctrl    = require('../controllers/instagramController');
const auth    = require('../middleware/auth');

router.get('/auth-url',         auth, ctrl.getAuthUrl);
router.get('/callback',              ctrl.handleCallback);
router.get('/profile',          auth, ctrl.getProfile);
router.get('/media',            auth, ctrl.getMedia);
router.get('/insights',         auth, ctrl.getInsights);
router.post('/publish/:reelId', auth, ctrl.publishReel);

module.exports = router;

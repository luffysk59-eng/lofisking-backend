const express = require('express');
const router  = express.Router();
const auth    = require('../middleware/auth');
const { query } = require('../config/db');

router.use(auth);

// GET /api/user/me
router.get('/me', (req, res) => res.json({ user: req.user }));

// PUT /api/user/me
router.put('/me', async (req, res) => {
  try {
    const { name, niche, igHandle } = req.body;
    const result = await query(
      'UPDATE users SET name=COALESCE($1,name), niche=COALESCE($2,niche), ig_handle=COALESCE($3,ig_handle), updated_at=NOW() WHERE id=$4 RETURNING id,name,email,phone,niche,ig_handle,plan',
      [name, niche, igHandle, req.user.id]
    );
    res.json({ user: result.rows[0] });
  } catch (err) {
    res.status(500).json({ error: 'Update failed' });
  }
});

module.exports = router;

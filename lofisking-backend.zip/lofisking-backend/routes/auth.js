const express = require('express');
const router  = express.Router();
const Joi     = require('joi');
const ctrl    = require('../controllers/authController');
const validate = require('../middleware/validate');
const { authLimiter } = require('../middleware/rateLimit');

const registerSchema = Joi.object({
  name:     Joi.string().min(2).max(60).required(),
  email:    Joi.string().email().optional(),
  phone:    Joi.string().pattern(/^\+?[\d\s\-]{7,20}$/).optional(),
  password: Joi.string().min(6).required(),
  igHandle: Joi.string().max(40).optional(),
}).or('email', 'phone');

const loginSchema = Joi.object({
  identifier: Joi.string().required(),
  password:   Joi.string().required(),
});

router.post('/register',    authLimiter, validate(registerSchema), ctrl.register);
router.post('/login',       authLimiter, validate(loginSchema),    ctrl.login);
router.post('/send-otp',    authLimiter, ctrl.sendOTPHandler);
router.post('/verify-otp',  authLimiter, ctrl.verifyOTPHandler);
router.post('/refresh',     ctrl.refreshToken);
router.post('/logout',      ctrl.logout);

module.exports = router;
